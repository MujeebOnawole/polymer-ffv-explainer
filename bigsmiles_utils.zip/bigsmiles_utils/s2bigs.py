# Import converter classes from the project-level module without relative hop
# This avoids "attempted relative import beyond top-level package" when
# importing this package as a plain directory module.
try:
    # Prefer importing the class directly to avoid star-import pitfalls
    from s2bigs import SMILES2BigSMILES  # type: ignore
except ModuleNotFoundError:
    # Try vendored minimal implementation bundled in this package
    try:
        from ._vendored_s2bigs import SMILES2BigSMILES  # type: ignore
    except Exception:
        # Fallback: locate a top-level s2bigs.py outside this package and import the class
        import os, importlib.util
        _pkg_dir = os.path.dirname(__file__)
        _here = os.path.abspath(__file__)
        _candidates = []
        _cur = _pkg_dir
        for _ in range(6):  # search up to 5 levels up
            _cand = os.path.join(_cur, 's2bigs.py')
            if os.path.exists(_cand) and os.path.abspath(_cand) != _here:
                _candidates.append(_cand)
            _cur = os.path.abspath(os.path.join(_cur, os.pardir))
        _found = _candidates[0] if _candidates else None
        if _found:
            _spec = importlib.util.spec_from_file_location('external_s2bigs', _found)
            _mod = importlib.util.module_from_spec(_spec)  
            assert _spec and _spec.loader
            _spec.loader.exec_module(_mod)  # type: ignore[attr-defined]
            try:
                SMILES2BigSMILES = getattr(_mod, 'SMILES2BigSMILES')
            except AttributeError as _e:
                raise ImportError(f"Found '{_found}' but it does not define SMILES2BigSMILES") from _e
        else:
            raise ModuleNotFoundError(
                "Could not locate top-level s2bigs.py and vendored version failed."
            )
