import re
from rdkit import Chem

# Optional deps for batch loaders; not required for single conversion
try:
    import pandas as pd  # noqa: F401
except Exception:
    pd = None  # type: ignore

try:
    from openpyxl import load_workbook  # noqa: F401
except Exception:
    load_workbook = None  # type: ignore


class BigSMILES2SMILES:
    def __init__(self):
        self.SMILES_data = None
        self.num = 0
        self.BigSMILES_data = None

    # Batch loaders (kept for compatibility; require optional deps)
    def Data_Load_xlsx(self, filename, data_only=True, BigSMILES='BigSMILES'):
        if load_workbook is None:
            raise ImportError("openpyxl is required for Data_Load_xlsx")
        import pandas as pd  # local import to avoid hard dependency at module import
        load_wb = load_workbook(filename, data_only)
        load_ws = load_wb.active
        data = pd.DataFrame([[i.value for i in j] for j in load_ws.rows])
        header = data.iloc[0]
        data = data[1:]
        data.rename(columns=header, inplace=True)
        data.dropna(subset=[BigSMILES], inplace=True)
        data.reset_index(drop=True, inplace=True)
        self.BigSMILES_data = data[BigSMILES]
        self.num = len(self.BigSMILES_data)

    def Data_Load_csv(self, filename, BigSMILES='BigSMILES', encoding='utf-8'):
        import pandas as pd  # local import to avoid hard dependency at module import
        data = pd.read_csv(filename, header=0, encoding=encoding)
        data.dropna(subset=[BigSMILES], inplace=True)
        data.reset_index(drop=True, inplace=True)
        self.BigSMILES_data = data[BigSMILES]
        self.num = len(self.BigSMILES_data)

    # Batch conversion (unused in our pipeline but kept)
    def Converting(self, resultfile='result'):
        import pandas as pd  # local import
        self.SMILES_data = []
        kk = 0
        for i in range(self.num):
            BigSMILES = self.BigSMILES_data[i]
            if '>,<' in BigSMILES:
                ind_x = BigSMILES.rfind(',')
                BigSMILES = BigSMILES[:ind_x]
            for j in ['<', '>', '{', '}', '\\$', ',', ' ']:
                BigSMILES = re.sub(j, '', BigSMILES)
            BigSMILES = '*' + BigSMILES + '*'
            BigSMILES = Chem.MolToSmiles(Chem.MolFromSmiles(BigSMILES))
            self.SMILES_data.append(BigSMILES)
            if i - kk == 100000:
                aa = pd.DataFrame(self.SMILES_data)
                aa.to_csv(resultfile + str(kk) + '.csv')
                kk = i
                self.SMILES_data = []
        if kk != i:
            aa = pd.DataFrame(self.SMILES_data)
            aa.to_csv(resultfile + str(kk) + '.csv')
            kk = i
            self.SMILES_data = []

    # Single-string conversion used by our pipeline
    def Converting_single(self, BigSMILES):
        if '>,<' in BigSMILES:
            ind_x = BigSMILES.rfind(',')
            BigSMILES = BigSMILES[:ind_x]
        for j in ['<', '>', '{', '}', '\\$', ',', ' ']:
            BigSMILES = re.sub(j, '', BigSMILES)
        BigSMILES = '*' + BigSMILES + '*'
        BigSMILES = Chem.MolToSmiles(Chem.MolFromSmiles(BigSMILES))
        return BigSMILES

