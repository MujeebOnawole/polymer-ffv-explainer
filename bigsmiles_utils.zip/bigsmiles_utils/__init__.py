from typing import Tuple

from rdkit import Chem

# Local converters (moved into this package)
from .s2bigs import SMILES2BigSMILES
from .bigs2s import BigSMILES2SMILES


def _canonicalize_smiles(smiles: str) -> str:
    try:
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            return smiles
        return Chem.MolToSmiles(mol)
    except Exception:
        return smiles


def roundtrip_or_fallback(smiles: str) -> Tuple[str, str, bool]:
    """
    Try to convert SMILES <-> BigSMILES and return a safe text representation.

    Returns:
        canonical_smiles: RDKit-canonicalized SMILES
        text_repr: BigSMILES string if conversion succeeded, else canonical SMILES
        used_bigsmiles: True if BigSMILES round-trip was used, else False
    """
    # Always canonicalize input SMILES first
    canonical = _canonicalize_smiles(smiles)

    # Attempt SMILES -> BigSMILES
    try:
        s2b = SMILES2BigSMILES()
        bigs = s2b.Converting_single(canonical)
    except Exception:
        bigs = None

    if isinstance(bigs, str) and '{' in bigs and '}' in bigs:
        # Attempt BigSMILES -> SMILES to ensure round-trip
        try:
            b2s = BigSMILES2SMILES()
            rt_smiles = b2s.Converting_single(bigs)
            rt_canonical = _canonicalize_smiles(rt_smiles)
            return rt_canonical, bigs, True
        except Exception:
            # If round-trip back fails, fall back to canonical SMILES
            return canonical, canonical, False

    # Fallback: use canonical SMILES as text representation
    return canonical, canonical, False

