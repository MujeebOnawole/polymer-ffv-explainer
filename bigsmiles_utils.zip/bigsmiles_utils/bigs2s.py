# Import converter classes from the project-level module without relative hop
# This avoids "attempted relative import beyond top-level package" when
# importing this package as a plain directory module.
try:
    from bigs2s import BigSMILES2SMILES  # type: ignore
except ModuleNotFoundError:
    try:
        from ._vendored_bigs2s import BigSMILES2SMILES  # type: ignore
    except Exception:
        import os, importlib.util
        _pkg_dir = os.path.dirname(__file__)
        _here = os.path.abspath(__file__)
        _candidates = []
        _cur = _pkg_dir
        for _ in range(6):
            _cand = os.path.join(_cur, 'bigs2s.py')
            if os.path.exists(_cand) and os.path.abspath(_cand) != _here:
                _candidates.append(_cand)
            _cur = os.path.abspath(os.path.join(_cur, os.pardir))
        _found = _candidates[0] if _candidates else None
        if _found:
            _spec = importlib.util.spec_from_file_location('external_bigs2s', _found)
            _mod = importlib.util.module_from_spec(_spec)
            assert _spec and _spec.loader
            _spec.loader.exec_module(_mod)  # type: ignore[attr-defined]
            try:
                BigSMILES2SMILES = getattr(_mod, 'BigSMILES2SMILES')
            except AttributeError as _e:
                raise ImportError(f"Found '{_found}' but it does not define BigSMILES2SMILES") from _e
        else:
            raise ModuleNotFoundError(
                "Could not locate top-level bigs2s.py and vendored version failed."
            )
