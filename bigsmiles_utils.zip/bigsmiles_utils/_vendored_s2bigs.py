import re
from collections import Counter
from rdkit import Chem
from rdkit import RDLogger

# Optional deps (used only in batch utilities)
try:
    import pandas as pd  # noqa: F401
except Exception:
    pd = None  # type: ignore

try:
    from openpyxl import load_workbook  # noqa: F401
except Exception:
    load_workbook = None  # type: ignore


class SMILES2BigSMILES:
    def __init__(self):
        self.SMILES_data = None
        self.num_data = 0
        self.BigSMILES_data = None
        self.nums = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0']
        RDLogger.DisableLog('rdApp.*')

        # Patterns from the original implementation
        self.check_unit_detail = [
            r'N\\d[()]*(c\\d?\\d?[()]*)*\\(=O\\)[()]*(c\\d?\\d?[()]*)*=O[()]*([cofs]\\d?\\d?[()]*)*\\(=O\\)[()]*(c\\d?\\d?[()]*)*N[()]*(c\\d?\\d?[()]*)*=O[()]*(c\\d?\\d?[()]*)*\\)',
            r'C\\(=O\\)(c\\d?\\d?[()]*)+OC\\(=O\\)(c\\d?\\d?[()]*)+C\\(=O\\)',
            r'C\\(=O\\)(c\\d?\\d?[()]*)+C\\(=O\\)',
            r'c\\d[()]?c[()]?c[()]?c[()]?c[()]?c\\d[()]?C\\(=O\\)[()]?c\\d[()]?c[()]?c[()]?c[()]?c[()]?c\\d\\)?',
            r'N[()]?c\\d[()]?c[()]?c[()]?c[()]?c[()]?c\\d[()]?C\\d[()]?[()]?OC\\(=O\\)c\\d[()]?c[()]?c[()]?c[()]?c[()]?c\\d\\d[()]?c\\d[()]?c[()]?c[()]?c[()]?c[()]?c\\d[()]?N\\)?',
            r'O[()]?c\\d[()]?c[()]?c[()]?c[()]?c[()]?c\\d[()]?C\\d[()]?[()]?OC\\(=O\\)c\\d[()]?c[()]?c[()]?c[()]?c[()]?c\\d\\d[()]?c\\d[()]?c[()]?c[()]?c[()]?c[()]?c\\d[()]?O\\)?',
            r'c\\d[()]?c[()]?c[()]?c[()]?c[()]?c\\d[()]?O[()]?c\\d[()]?c[()]?c[()]?c[()]?c[()]?c\\d[()]?O[()]?c\\d[()]?c[()]?c[()]?c[()]?c[()]?c\\d\\)?',
            r'Oc\\d[()]?c[()]?c[()]?c[()]?c[()]?c\\d[()]?S\\(=O\\)\\(=O\\)[()]?c\\d[()]?c[()]?c[()]?c[()]?c[()]?c\\d\\)?O',
            r'O[()]*(c\\d?\\d?[()]*)+(F[()]*)*(Cl[()]*)*(F[()]*)*(Cl[()]*)*(c\\d?\\d?[()]*)*(F[()]*)*(Cl[()]*)*(F[()]*)*(Cl[()]*)*(c\\d?\\d?[()]*)+O',
            r'O[()]*(c\\d?\\d?[()]*)+Cl[()]*(c\\d?\\d?[()]*)*Cl[()]*(c\\d?\\d?[()]*)*Cl[()]*(c\\d?\\d?[()]*)*Cl[()]*(c\\d?\\d?[()]*)+O',
            r'O[()]*(c\\d?\\d?[()]*)+Cl[()]*(c\\d?\\d?[()]*)*Cl[()]*(c\\d?\\d?[()]*)+O',
            r'O[()]*(c\\d?\\d?[()]*)+Br[()]*(c\\d?\\d?[()]*)*Br[()]*(c\\d?\\d?[()]*)*Br[()]*(c\\d?\\d?[()]*)*Br[()]*(c\\d?\\d?[()]*)+O',
            r'O[()]*(c\\d?\\d?[()]*)+Br[()]*(c\\d?\\d?[()]*)*Br[()]*(c\\d?\\d?[()]*)+O',
            r'O[()]*(c\\d?\\d?[()]*)+C\\(=\\(Cl\\)Cl[()]*(c\\d?\\d?[()]*)+O',
            r'O[()]*(c\\d?\\d?[()]*)+(Cl)?S?[()]*(c\\d?\\d?[()]*)+O',
            r'c\\d[()]?c[()]?c[()]?c[()]?c[()]?c\\d[()]?S\\(=O\\)\\(=O\\)[()]?c\\d[()]?c[()]?c[()]?c[()]?c[()]?c\\d\\)?',
            r'c\\d[()]?c[()]?c[()]?c[()]?c[()]?c\\d[()]?O[()]?c\\d[()]?c[()]?c[()]?c[()]?c[()]?c\\d\\)?',
            r'c\\d[()]?c[()]?c[()]?c[()]?c[()]?c\\d\\)?',
            r'O(c\\d?\\d?[()]*)+O(c\\d?\\d?[()]*)+O',
            r'O(c\\d?\\d?[()]*)+O',
            r'c\\d[()]?c[()]?c[()]?c[()]?n[()]?n\\d\\)',
            r'C\\(=O\\)(c\\d?\\d?[()]*)+O(c\\d?\\d?[()]*)+O(c\\d?\\d?[()]*)+O(c\\d?\\d?[()]*)+C\\(=O\\)',
            r'C\\(=O\\)(c\\d?\\d?[()]*)+O(c\\d?\\d?[()]*)+C\\(=O\\)',
        ]

        self.check_unit_full_match = [
            r'(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+S\\(=O\\)\\(=O\\)(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+',
            r'(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+O(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+',
            r'(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+S\\(=O\\)\\(=O\\)(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+',
            r'(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+O(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+',
            r'(c\\d?\\d?[()]*)+S\\(=O\\)\\(=O\\)(c\\d?\\d?[()]*)+',
            r'(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+C\\(=O\\)(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+',
            r'(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+C\\(=O\\)(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+',
            r'(c\\d?\\d?[()]*)+C\\(=O\\)(c\\d?\\d?[()]*)+',
            r'(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+O(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+',
            r'(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+O(c\\d?\\d?[()]*)+(n\\d?\\d?[()]*)(c\\d?\\d?[()]*)+',
            r'(c\\d?\\d?[()]*)+O(c\\d?\\d?[()]*)+',
            r'N(c\\d?\\d?[()]*)+O(c\\d?\\d?[()]*)+N',
            r'N(c\\d?\\d?[()]*)+N',
            r'(c\\d?c\\d?\\[()]*)+',
            r'C\\(=O\\)',
            r'CC\\(C\\(C\\)=C\\)',
            r'C\\\\C=C\\(C\\)\\/C',
            r'C\\/C=C\\(C\\)\\/C',
            r'CC\\(OC\\(=O\\)C\\)',
            r'OC\\(C\\)C\\(=O\\)',
            r'C\\(=O\\)CCCCC\\(=O\\)NCCCCCCN',
            r'CC=CC',
            r'C\\\\C=C\\/C',
            r'C\\/C=C\\/C',
            r'CC\\(Cl\\)=CC',
            r'CC\\(Cl\\)',
            r'C\\(F\\)\\(F\\)C\\(F\\)\\(F\\)',
            r'CC\\(F\\)\\(F\\)',
            r'CC\\(C\\)\\(C\\(=O\\)OC\\)',
            r'CC\\(C\\(=O\\)OC\\)',
            r'CC\\(C\\)\\(C\\(=O\\)O\\)',
            r'CC\\(C\\(=O\\)O\\)',
            r'CC\\(C\\(=O\\)\\[O-\\]\\)',
            r'CC\\(C\\(=O\\)\\[O-\\]\\)',
            r'CC\\(C\\(=O\\)OCCCC\\)',
            r'CC\\(C\\(=O\\)OCC\\)',
            r'CC\\(C\\(=O\\)OCC\\(CC\\)CCCC\\)',
            r'CC\\(C\\(=O\\)N\\)',
            r'CC\\(C#N\\)',
            r'CC\\(C\\(=O\\)NC\\(C\\)C\\)',
            r'CC\\(C\\(=O\\)N\\(C\\)C\\)',
            r'CC\\(c\\dccc\\(Cl\\)cc\\d\\)',
            r'CC\\(c\\dc\\(Cl\\)cccc\\d\\)',
            r'CC\\(c\\dccc\\(CCl\\)cc\\d\\)',
            r'CC\\(c\\dccc\\(S\\(=O\\)\\(=O\\)O\\)cc\\d\\)',
            r'CC\\(c\\dccc\\(S\\(=O\\)\\(=O\\)\\[O-\\]\\)cc\\d\\)',
            r'CC\\(c\\dccncc\\d\\)',
            r'CC\\(c\\dncccc\\d\\)',
            r'CC\\(C\\)O',
            r'OCC\\(=O\\)',
            r'OCCCCCC\\(=O\\)',
            r'NCCCCCC\\(=O\\)',
            r'Cc\\dccc\\(cc\\d\\)C',
            r'Cc\\dccccc\\(c\\d\\)C',
            r'C\\(S\\d\\)=CC=C\\d',
            r'c\\(cc\\d\\)ccc\\dC=C',
            r'C\\(S\\d\\)=C\\dOCCOC\\d=C\\d',
            r'C\\(N\\d\\)=CC=C\\d',
            r'c\\(cc\\d\\)ccc\\dS',
            r'C=C',
            r'c\\(cc\\d\\)ccc\\dN',
            r'c\\(cc\\d\\)ccc\\dN=C\\(C=C\\d\\)C=CC\\d=N',
        ]

        self.check_unit_full_match.extend(self.check_unit_detail)

    # Additional methods omitted for brevity in this excerpt
    # We port only the single-string converter that our pipeline uses,
    # along with minimal helpers used by it.

    def switching(self, SMILES):
        # Minimal passthrough; original contained advanced logic.
        # For our purposes, ensure RDKit round-trip validity and return the input.
        try:
            if Chem.MolFromSmiles('*' + SMILES.strip('*') + '*') is None:
                return None
            return SMILES
        except Exception:
            return None

    def Converting_single(self, SMILES, move_parallel=-1):
        if Counter(SMILES)['*'] != 2:
            return 0
        tmp = Chem.MolToSmiles(Chem.MolFromSmiles(SMILES))
        tmp = re.sub(r'(\\[[^\\[^\\]^\\-]*)-([^\\[^\\]^\\-]*\\])', '\\1:\\2', tmp)
        tmp = re.sub('-', '', tmp)
        SMILES = re.sub(':', '-', tmp)

        br = self.switching(SMILES)
        if not br:
            return 0
        SMILES = br

        # Simplified conversion path that mirrors original structure for common cases
        SMILES = SMILES.strip('*')
        SMILES_delete1 = re.sub(r'\\([^()]*\\)|\\s-\\s.*', '', SMILES)

        # Special case from original for CCO (propylene AB type)
        if 'CCO' == SMILES_delete1 and SMILES != SMILES_delete1:
            first = '<' + SMILES + '>'
            second = '<' + SMILES[1:-1] + SMILES[0] + SMILES[-1] + '>'
            return '{' + first + ',' + second + '}'

        # Fallback simplified BigSMILES form with a single reactive block
        return '{<' + SMILES + '>}'

